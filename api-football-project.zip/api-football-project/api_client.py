"""
Client API-Football : fonctions pour récupérer les données joueurs.
"""
import requests
from config import BASE_URL, HEADERS


class APIFootballError(Exception):
    pass


def _get(endpoint: str, params: dict) -> dict:
    """Appel générique GET vers l'API, avec gestion d'erreurs basique."""
    url = f"{BASE_URL}/{endpoint}"
    response = requests.get(url, headers=HEADERS, params=params, timeout=15)

    if response.status_code == 401 or response.status_code == 403:
        raise APIFootballError(
            "Clé API invalide ou manquante. Vérifie config.py / API_FOOTBALL_KEY."
        )
    if response.status_code == 429:
        raise APIFootballError(
            "Limite de requêtes quotidienne atteinte (plan Free = 100/jour)."
        )

    response.raise_for_status()
    data = response.json()

    if data.get("errors"):
        raise APIFootballError(f"Erreur API : {data['errors']}")

    return data


def search_player(name: str, season: int) -> list[dict]:
    """
    Recherche un joueur par nom (ex: "Messi") et retourne ses stats
    pour la saison demandée. Peut retourner plusieurs résultats si
    le joueur a plusieurs entrées (transferts en cours de saison, etc.)
    """
    data = _get("players", {"search": name, "season": season})
    results = []

    for entry in data.get("response", []):
        player = entry["player"]
        stats_list = entry.get("statistics", [])
        if not stats_list:
            continue

        # On prend la stat avec le plus d'apparitions (équipe principale de la saison)
        stats = max(stats_list, key=lambda s: s["games"]["appearences"] or 0)

        results.append({
            "name": player.get("name"),
            "photo": player.get("photo"),
            "nationality": player.get("nationality"),
            "age": player.get("age"),
            "team_name": stats["team"]["name"],
            "team_logo": stats["team"]["logo"],
            "league_name": stats["league"]["name"],
            "goals": stats["goals"]["total"] or 0,
            "assists": stats["goals"]["assists"] or 0,
            "appearances": stats["games"]["appearences"] or 0,
            "minutes": stats["games"]["minutes"] or 0,
            "rating": stats["games"]["rating"],
            "season": season,
        })

    return results


if __name__ == "__main__":
    # Petit test manuel : python api_client.py
    import json
    try:
        res = search_player("Messi", 2025)
        print(json.dumps(res, indent=2, ensure_ascii=False))
    except APIFootballError as e:
        print(f"Erreur : {e}")
