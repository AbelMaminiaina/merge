"""
Génère un fichier HTML simple affichant les stats d'un joueur.
"""
import datetime
from pathlib import Path

OUTPUT_DIR = Path(__file__).parent / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Stats — {name}</title>
<style>
  body {{
    font-family: Arial, sans-serif;
    background: #f5f5f5;
    margin: 0;
    padding: 40px;
  }}
  .container {{
    max-width: 600px;
    margin: 0 auto;
    background: #ffffff;
    border-radius: 8px;
    padding: 32px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.1);
  }}
  .header {{
    display: flex;
    align-items: center;
    gap: 20px;
    border-bottom: 1px solid #e0e0e0;
    padding-bottom: 20px;
    margin-bottom: 20px;
  }}
  .header img {{
    width: 90px;
    height: 90px;
    border-radius: 50%;
    object-fit: cover;
  }}
  h1 {{
    margin: 0;
    font-size: 24px;
  }}
  .sub {{
    color: #666;
    font-size: 14px;
    margin-top: 4px;
  }}
  table {{
    width: 100%;
    border-collapse: collapse;
  }}
  td {{
    padding: 10px 0;
    border-bottom: 1px solid #eee;
  }}
  td.label {{
    color: #666;
  }}
  td.value {{
    text-align: right;
    font-weight: bold;
  }}
  .footer {{
    margin-top: 20px;
    font-size: 12px;
    color: #999;
    text-align: right;
  }}
</style>
</head>
<body>
  <div class="container">
    <div class="header">
      <img src="{photo}" alt="">
      <div>
        <h1>{name}</h1>
        <div class="sub">{team_name} — {league_name} — Saison {season}</div>
        <div class="sub">{nationality}, {age} ans</div>
      </div>
    </div>
    <table>
      <tr><td class="label">Buts</td><td class="value">{goals}</td></tr>
      <tr><td class="label">Passes décisives</td><td class="value">{assists}</td></tr>
      <tr><td class="label">Matchs joués</td><td class="value">{appearances}</td></tr>
      <tr><td class="label">Minutes jouées</td><td class="value">{minutes}</td></tr>
      <tr><td class="label">Note moyenne</td><td class="value">{rating}</td></tr>
    </table>
    <div class="footer">Données API-Football — généré le {generated_date}</div>
  </div>
</body>
</html>
"""


def render_player_html(player: dict, output_name: str = "player.html") -> Path:
    """Génère le fichier HTML à partir des données d'un joueur."""
    html = HTML_TEMPLATE.format(
        name=player.get("name") or "—",
        photo=player.get("photo") or "",
        team_name=player.get("team_name") or "—",
        league_name=player.get("league_name") or "—",
        season=player.get("season") or "—",
        nationality=player.get("nationality") or "—",
        age=player.get("age") or "—",
        goals=player.get("goals", 0),
        assists=player.get("assists", 0),
        appearances=player.get("appearances", 0),
        minutes=player.get("minutes", 0),
        rating=player.get("rating") or "—",
        generated_date=datetime.date.today().strftime("%d/%m/%Y"),
    )

    output_path = OUTPUT_DIR / output_name
    output_path.write_text(html, encoding="utf-8")
    return output_path
