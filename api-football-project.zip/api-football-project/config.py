"""
Configuration du projet : clé API et endpoint.
"""
import os

# Colle ta clé ici, ou définis la variable d'environnement API_FOOTBALL_KEY
API_KEY = os.environ.get("API_FOOTBALL_KEY", "COLLE_TA_CLE_ICI")

BASE_URL = "https://v3.football.api-sports.io"

HEADERS = {
    "x-apisports-key": API_KEY
}

DEFAULT_SEASON = 2025  # la saison "2026" (2026-2027) n'a pas encore commencé pour la plupart des ligues
