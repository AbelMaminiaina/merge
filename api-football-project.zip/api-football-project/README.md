# Stats joueur API-Football → HTML

Projet minimal : tu donnes un nom de joueur, le script va chercher ses stats
sur l'API-Football et génère une page HTML simple avec les données.

## Installation

```bash
pip install requests
```

## Configuration de la clé API

1. Crée un compte gratuit sur https://dashboard.api-football.com
2. Récupère ta clé dans le dashboard (plan Free = 100 requêtes/jour)
3. Mets-la dans `config.py` (remplace `COLLE_TA_CLE_ICI`)
   — ou définis la variable d'environnement avant de lancer :
   ```bash
   export API_FOOTBALL_KEY="ta_cle_ici"
   ```

## Utilisation

```bash
python main.py Messi
python main.py Mbappe --season 2025
```

Le fichier HTML généré se trouve dans `output/<nom>.html` — ouvre-le
directement dans ton navigateur.

## Fichiers

- `config.py` — clé API et configuration
- `api_client.py` — appel à l'API et mise en forme des données (`search_player`)
- `render_html.py` — génère le fichier HTML à partir des données
- `main.py` — script à lancer, relie tout

## Note sur la saison

Le paramètre `season` correspond à l'année de **début** de la saison
(ex: `2025` = saison 2025-2026 pour les championnats européens).
Si un joueur ne ressort pas pour une saison donnée, essaie l'année
précédente ou suivante.
