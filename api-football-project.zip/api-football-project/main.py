"""
Script principal : recherche un joueur par nom et génère le HTML de ses stats.

Usage :
    python main.py Messi
    python main.py Messi --season 2025
"""
import argparse
import sys

from config import DEFAULT_SEASON
from api_client import search_player, APIFootballError
from render_html import render_player_html


def main():
    parser = argparse.ArgumentParser(description="Stats joueur (API-Football) -> HTML")
    parser.add_argument("name", help="Nom du joueur, ex: Messi")
    parser.add_argument("--season", type=int, default=DEFAULT_SEASON)
    args = parser.parse_args()

    print(f"Recherche de '{args.name}' (saison {args.season})...")
    try:
        results = search_player(args.name, args.season)
    except APIFootballError as e:
        print(f"Erreur API : {e}")
        sys.exit(1)

    if not results:
        print(f"Aucun résultat pour '{args.name}' en saison {args.season}.")
        print("Essaie une autre saison si le joueur n'a pas joué cette année-là.")
        sys.exit(1)

    player = results[0]
    print(f"Trouvé : {player['name']} ({player['team_name']}) — "
          f"{player['goals']} buts, {player['assists']} passes D.")

    output_path = render_player_html(player, output_name=f"{args.name.lower()}.html")
    print(f"Fichier généré : {output_path}")


if __name__ == "__main__":
    main()
